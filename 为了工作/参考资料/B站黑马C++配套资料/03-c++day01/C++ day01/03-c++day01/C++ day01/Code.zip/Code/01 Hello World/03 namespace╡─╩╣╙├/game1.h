#include <iostream>
using namespace std;

namespace LOL
{
	void goAtk();
}





