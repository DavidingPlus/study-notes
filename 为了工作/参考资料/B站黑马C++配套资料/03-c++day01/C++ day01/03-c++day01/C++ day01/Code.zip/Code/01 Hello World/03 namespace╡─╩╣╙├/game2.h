#include <iostream>
using namespace std;

namespace KingGlory
{
	void goAtk();
}

