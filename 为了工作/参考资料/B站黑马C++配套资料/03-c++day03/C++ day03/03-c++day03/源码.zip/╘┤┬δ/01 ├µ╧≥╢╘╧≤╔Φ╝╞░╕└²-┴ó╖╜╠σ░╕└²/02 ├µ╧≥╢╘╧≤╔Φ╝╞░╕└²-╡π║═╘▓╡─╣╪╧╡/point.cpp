#include "point.h"

void Point::setX(int x)
{
	m_X = x;
}
void Point::setY(int y)
{
	m_Y = y;
}

int Point::getX()
{
	return m_X;
}

int Point::getY()
{
	return m_Y;
}