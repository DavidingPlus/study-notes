#define _CRT_SECURE_NO_WARNINGS
#include<iostream>
#include<string>
using namespace std;

template<class  NameType, class AgeType>
class Person
{
public:
	Person(NameType name, AgeType age)
	{
		this->name = name;
		this->age = age;
	}
	void show()
	{
		cout << this->name << " ";
		cout << this->age << endl;
	}

	NameType name;
	AgeType age;
};


void dowork(Person<string, int>&p)
{
	p.show();
}

void test()
{
	Person<string, int>p("³����", 20);

	dowork(p);

}


template<class T1,class T2>
void  dowork02(Person<T1,T2>&p)
{
	cout << typeid(T1).name() << endl;
	cout << typeid(T2).name() << endl;
	p.show();
}

void test02()
{
	Person<string, int>p("�ֳ�", 30);
	
	dowork02(p);
	p.show();

}


template <class T>

void dowork03(T&p)
{
	cout << typeid(T).name() << endl;
	p.show();

}
void test03()
{
	Person<string, int>p("�ν�",100);

	dowork03(p);
	p.show();


}


int main(){


	//test();
	test02();
	//test03();
	system("pause");
	return EXIT_SUCCESS;
}