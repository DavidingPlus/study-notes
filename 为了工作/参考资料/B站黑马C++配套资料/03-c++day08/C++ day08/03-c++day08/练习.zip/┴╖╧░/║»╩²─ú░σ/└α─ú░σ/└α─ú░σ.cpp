#define _CRT_SECURE_NO_WARNINGS
#include<iostream>
#include<string>
using namespace std;
//ģ����
template<class T1, class T2>
class stu
{
public:	
	stu(T1 str, T2 myage)
	{
		this->m_age = myage;
		this->m_str = str;
	}
	void shou()
	{
		cout << this->m_str << " "<<this->m_age << endl;
	}

		T1 m_str;
		T2 m_age;
};



void dowork(stu<string, int> & p)
{
	p.shou();
}



void test()
{

	stu<string, int> p1("���",19);

	dowork(p1);

}



template<class T1,class T2>
void dowork02(stu<T1, T2>&p)
{
	cout << typeid(T1).name() << endl;
	cout << typeid(T2) .name()<< endl;
	p.shou();
}



void test01()
{
	stu<string, int>p1("̹��", 21);
	dowork02(p1);
}


template<class T1>
void dowork02(T1 &p)
{
	cout << typeid(T1).name() << endl;
	p.show();	
}

void test02()
{
	stu<string, int>p1("����", 100);
	dowork02(p1);
}



int main(){

	//test();
	//test01();
	test02();
	system("pause");
	return EXIT_SUCCESS;
}