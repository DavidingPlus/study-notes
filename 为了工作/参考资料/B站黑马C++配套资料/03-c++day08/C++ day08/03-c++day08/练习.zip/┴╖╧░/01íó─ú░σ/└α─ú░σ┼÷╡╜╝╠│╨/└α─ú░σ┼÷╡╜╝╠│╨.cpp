#define _CRT_SECURE_NO_WARNINGS
#include<iostream>
#include<string>
using namespace std;

template<class T1>
class Person
{
public:
	Person(){}
	T1 name;
};





template<class T1,class T2>
class Person1 :public Person<T1>
{
public:
	Person1()
	{
		cout << typeid(T1).name() << endl;
		cout << typeid(T2).name() << endl;
	}

};

void test()
{
	Person1<double, int> p1;
}




int main(){

	test();

	system("pause");
	return EXIT_SUCCESS;
}