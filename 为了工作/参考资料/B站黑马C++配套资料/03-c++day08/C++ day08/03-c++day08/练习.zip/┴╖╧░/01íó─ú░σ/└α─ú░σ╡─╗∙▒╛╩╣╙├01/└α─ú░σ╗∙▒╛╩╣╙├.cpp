#define _CRT_SECURE_NO_WARNINGS
#include<iostream>
#include<string>
using namespace std;
//��ģ��
template<class  NameType,class AgeType=int>
class Person
{
public:
	Person(NameType name, AgeType age)
	{
		this->name = name;
		this->age = age;
	}
	void show()
	{
		cout << this->name << " ";
		cout << this->age << endl;
	}

	NameType name;
	AgeType age;
};


template <class Int ,class Double>
class Person1
{
public:
	Person1(Int age,Double size)
	{
		this->age = age;
		this->size = size;

	}
	void show()
	{
		cout << "this->age:" << age << endl;
		cout << "this->size:" << size << endl;
	}

	Int age;
	Double size;

};





void test()
{
	Person<string, int>p("ƤƤϺ", 100);
	p.show();

}


void test01()
{
	Person1<int, double>p(100, 3.14);
	p.show();


}



int main(){


	//test();
	test01();
	system("pause");
	return EXIT_SUCCESS;
}