#define _CRT_SECURE_NO_WARNINGS
#include<iostream>
using namespace std;

template <class T>
void mySwap(T &a, T&b)
{
	T temp = a;
	a = b;
	b = temp;
}



void test()
{
	int a = 10;
	int b = 20;

	mySwap<int>(a, b);

	cout << a << endl;
	cout << b << endl;

}




int main(){


	test();
	system("pause");
	return EXIT_SUCCESS;
}