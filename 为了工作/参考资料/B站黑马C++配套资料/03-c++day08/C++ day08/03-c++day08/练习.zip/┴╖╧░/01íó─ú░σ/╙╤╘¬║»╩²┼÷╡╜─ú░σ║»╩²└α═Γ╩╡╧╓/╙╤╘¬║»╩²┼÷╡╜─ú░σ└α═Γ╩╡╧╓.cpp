#define _CRT_SECURE_NO_WARNINGS
#include<iostream>
#include<string>
using namespace std;

template<class T1, class T2>class Person;
template<class T1, class T2>void print(Person<T1, T2>&p);


template<class T1,class T2>
class Person
{
	//����Ҫ����<>
	friend void print<>(Person<T1,T2>&p);
public:

	Person(T1 age,T2 name)
	{
		this->age = age;
		this->name = name;
	}

private:
	T1 age;
	T2 name;

};

template<class T1,class T2>
void print(Person<T1, T2> &p)
{
	cout << p.name << endl;
	cout << p.age << endl;
}



void test()
{

	Person<string, int>p1("rosi",100);
	print(p1);

}




int main(){

	test();

	system("pause");
	return EXIT_SUCCESS;
}