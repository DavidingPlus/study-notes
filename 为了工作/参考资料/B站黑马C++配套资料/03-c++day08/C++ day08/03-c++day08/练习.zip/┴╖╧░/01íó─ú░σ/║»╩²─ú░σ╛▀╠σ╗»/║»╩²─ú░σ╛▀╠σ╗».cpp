#define _CRT_SECURE_NO_WARNINGS
#include<iostream>
#include<string>
using namespace std;

class Person
{
public:
	Person(int age, string name)
	{	
		this->name = name;
		this->age = age;
	}
	string name;
	int age;
};

bool compre(int a, int b)
{
	cout << "���庯������" << endl;
	if (a == b)
	{
		return true;
	}
	return false;

}

bool compre(Person a, Person b)
{
	cout << "lllll" << endl;
	if (a.age == b.age)
	{
		return true;
	}
	return false;

}




//ģ�庯������T�滻�ɴ��������������
template<class T>
bool compre(T &a, T &b)
{
	cout << "Ĭ��ģ�����" << endl;
	if (a == b)
	{
		return true;
	}
	return false;
}

template<> bool compre<Person>(Person&a, Person &b)
{
	cout << "ģ����廯����" << endl;
	if (a.age == b.age)
	{
		return true;
	}
	return false;
}



void test()
{
	Person p1(10,"luxi");
	Person p2(10,"rosi");
	
	int a = 10;
	int b = 10;

	char a1='a';
	char b1='b';
	int i = compre(p1, p2);
	cout << i << endl;



}




int main(){


	test();
	system("pause");
	return EXIT_SUCCESS;
}