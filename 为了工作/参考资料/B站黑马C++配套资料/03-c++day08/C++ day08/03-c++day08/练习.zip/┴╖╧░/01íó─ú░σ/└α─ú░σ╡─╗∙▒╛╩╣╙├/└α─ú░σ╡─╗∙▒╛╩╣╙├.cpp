#define _CRT_SECURE_NO_WARNINGS
#include<iostream>
using namespace std;
class Person1
{
public:
	void show1()
	{
		cout << "person1����" << endl;
	}
};



class Person2
{
public:
	void show2()
	{
		cout << "person2����" << endl;
	}

};

//ģ����
template <class T>
class caperson
{
public:
	T obj;
	void func1()
	{
		obj.show1();
	}

	void func2()
	{
		obj.show2();
	}

};


void test()
{
	caperson<Person1>m;
	m.func1();
	//m.func2();

}


int main(){
	test();


	system("pause");
	return EXIT_SUCCESS;
}