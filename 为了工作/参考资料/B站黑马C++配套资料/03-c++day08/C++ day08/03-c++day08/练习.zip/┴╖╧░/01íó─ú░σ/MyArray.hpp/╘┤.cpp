#include"MyArray.hpp"


void print(MyArray<int> &p)
{
	for (int i = 0; i < p.getArraysize(); ++i)
	{
		cout << p[i] << endl;
	}
}


void test()
{
	MyArray<int>p(10);

	for (int i = 0; i < p.getm_Capacity(); ++i)
	{
		p.pushback(100+i);
	}
	cout << p[1] << endl;
	cout << p.getArraysize() << endl;
	print(p);
}


void main()
{
	test();
	system("pause");
}