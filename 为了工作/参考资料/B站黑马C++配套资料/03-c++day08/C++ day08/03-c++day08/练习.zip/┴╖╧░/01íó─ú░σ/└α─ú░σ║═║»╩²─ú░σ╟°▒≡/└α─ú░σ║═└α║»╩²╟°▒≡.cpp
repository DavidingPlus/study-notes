#define _CRT_SECURE_NO_WARNINGS
#include<iostream>
using namespace std;

template<class T1>
class Person
{
public:
	Person(){}

	static int a;

};


void test()
{
	Person p1;


}








int main(){

	test();

	system("pause");
	return EXIT_SUCCESS;
}