#define _CRT_SECURE_NO_WARNINGS
#include<iostream>
#include<string>
#include"muban.hpp"
using namespace std;



int main(){

	Person<string,int>p1("����", 100);
	p1.show();

	system("pause");
	return EXIT_SUCCESS;
}