#define _CRT_SECURE_NO_WARNINGS
#include<iostream>
#include<string>
using namespace std;

template<class T1>
class Person
{
public:
	Person(){}
		
	T1 age;
};


template<class T1,class T2>
class Person1 :public Person < T1 >
{
public:
	Person1(T1 age, T2 name)
	{
		this->name = name;
		this->age = age;
	}

	void show()
	{
		cout << typeid(T1).name() << endl;
		cout << typeid(T2).name() << endl;
		cout << "this->name:" << this->name << endl;
		cout << "this->age:" << this->age << endl;
	}
	T2 name;
};
void test()
{
	Person1<int, string>p1(100, "bbb");
	p1.show();
}


int main(){

	test();
	system("pause");
	return EXIT_SUCCESS;
}