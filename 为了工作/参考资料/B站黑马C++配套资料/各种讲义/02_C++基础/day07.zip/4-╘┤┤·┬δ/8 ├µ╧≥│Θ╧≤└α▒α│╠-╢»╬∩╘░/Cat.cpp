#include "Cat.h"


Cat::Cat()
{
	cout << "cat().." << endl;

}


Cat::~Cat()
{
	cout << "~cat().." << endl;

}

void Cat::voice()
{
	cout << "Сè��ʼ���ˣ�66666" << endl;
}
