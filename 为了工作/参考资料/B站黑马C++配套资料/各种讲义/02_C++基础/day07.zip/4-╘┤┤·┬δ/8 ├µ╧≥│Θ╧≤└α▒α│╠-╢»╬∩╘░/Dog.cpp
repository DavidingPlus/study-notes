#include "Dog.h"


Dog::Dog()
{
	cout << "Dog().." << endl;
}


Dog::~Dog()
{
	cout << "~Dog().." << endl;
}

void Dog::voice()
{
	cout << "����ʼ���ˣ� 555" << endl;
}
